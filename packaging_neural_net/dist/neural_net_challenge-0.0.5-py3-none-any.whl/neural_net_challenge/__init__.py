name = "neural_net_challenge"
